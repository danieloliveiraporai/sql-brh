﻿Musica musica1 = new Musica();
musica1.nome = "Roxane";
musica1.dataLancamento = DateTime.Parse("12/12/2008");

